"use strict";
const { createHash } = require("node:crypto");
const jwt = require("jsonwebtoken");
const { validateParams } = require("./schema.cjs");
const fail = (message, status = 409) =>
  Object.assign(new Error(message), { status });
function productAuthority(product, environment) {
  if (typeof product !== 'string' || !/^[a-z][a-z0-9-]*$/.test(product)) throw fail('Invalid product authority',400);
  if (!['prod','dev'].includes(environment)) throw fail('Select prod or dev explicitly',400);
  return product + ':' + environment;
}
/** K_SERVICE is supplied by Cloud Run, never by the request or its assertion. */
function runtimeProductEnvironment(product, serviceName = process.env.K_SERVICE) {
  productAuthority(product,'prod');
  for (const environment of ['prod','dev']) if (serviceName === product + '-api-' + environment) return environment;
  throw fail('The product runtime environment could not be verified',503);
}
function runtimeProductAuthority(product, serviceName) {
  return productAuthority(product,runtimeProductEnvironment(product,serviceName));
}
/** A Cloud Run revision is immutable: bind review to its source code and evidence. */
function runtimeReviewVersion(product, evidence, serviceName = process.env.K_SERVICE, revisionName = process.env.K_REVISION) {
  const authority = runtimeProductAuthority(product,serviceName);
  if (typeof revisionName !== 'string' || !/^[a-z][a-z0-9-]{0,62}$/.test(revisionName) || !revisionName.startsWith(serviceName+'-'))
    throw fail('The product source revision could not be verified',503);
  return hashIntent({authority,revision:revisionName,evidence});
}
function finalReceipt(row) {
  return row && Number.isInteger(row.responseStatus) &&
    (row.state === 'completed' && row.responseStatus >= 200 && row.responseStatus < 300 && row.responseBody?.success === true ||
     row.state === 'failed' && row.responseStatus >= 400 && row.responseStatus <= 599 && row.responseBody?.success === false);
}
function hashIntent(value) {
  const sort = (v) =>
    Array.isArray(v)
      ? v.map(sort)
      : v && typeof v === "object"
        ? Object.fromEntries(
            Object.keys(v)
              .sort()
              .map((k) => [k, sort(v[k])]),
          )
        : v;
  return createHash("sha256")
    .update(JSON.stringify(sort(JSON.parse(JSON.stringify(value)))))
    .digest("hex");
}
function redact(value) {
  if (value instanceof Date) return value.toISOString();
  if (typeof value?.toJSON === "function") return redact(value.toJSON());
  if (Array.isArray(value)) return value.map(redact);
  if (!value || typeof value !== "object") return value;
  return Object.fromEntries(
    Object.entries(value)
      .filter(
        ([key]) =>
          !/^(signed_payload|password.*|.*token.*|.*secret.*|.*private.*key.*|api_?key|key|key_hash|otp.*|completionCode)$/i.test(
            key,
          ),
      )
      .map(([key, v]) => [key, redact(v)]),
  );
}
/** query must use the same transaction context as the owning business handlers. */
function createPostgresOperationStore(query) {
  return {
    async claim(row) {
      const result = await query(
        `INSERT INTO "staff_admin_operations" (id,"actorId",method,path,"requestHash","targetKey") VALUES ($1::uuid,$2,$3,$4,$5,$6) ON CONFLICT DO NOTHING RETURNING id`,
        [
          row.id,
          row.actorId,
          row.method,
          row.path,
          row.requestHash,
          row.targetKey,
        ],
      );
      return result.rows.length === 1;
    },
    async get(id) {
      return (
        (
          await query(
            'SELECT * FROM "staff_admin_operations" WHERE id=$1::uuid',
            [id],
          )
        ).rows[0] ?? null
      );
    },
    async finish(id, state, status, body) {
      const result = await query(
        'UPDATE "staff_admin_operations" SET state=$2,"responseStatus"=$3,"responseBody"=$4::jsonb,"updatedAt"=CURRENT_TIMESTAMP WHERE id=$1::uuid AND state NOT IN (\'completed\',\'failed\') RETURNING id',
        [id, state, status, JSON.stringify(body)],
      );
      if (result.rows.length !== 1) {
        const prior = await this.get(id);
        if (!finalReceipt(prior))
          throw fail("Original product receipt is missing", 503);
      }
    },
  };
}
function capture(req, res, next, timeoutMs) {
  return new Promise((resolve, reject) => {
    const timer =
      timeoutMs === null
        ? null
        : setTimeout(
            () =>
              reject(
                fail(
                  "The product handler did not complete a verified response",
                  504,
                ),
              ),
            timeoutMs,
          );
    res.json = (body) => {
      clearTimeout(timer);
      resolve({ status: res.statusCode, body });
      return res;
    };
    res.send = (body) => {
      clearTimeout(timer);
      if (res.statusCode === 204)
        resolve({ status: 200, body: { success: true, data: null } });
      else reject(fail("Native administration requires a JSON result", 502));
      return res;
    };
    try {
      next();
    } catch (error) {
      clearTimeout(timer);
      reject(error);
    }
  });
}
/** This verifies a narrow corporate assertion. It never creates a customer/platform login. */
function createStaffAdminBoundary(options) {
  const {
    product,
    secret,
    store,
    reviewTarget,
    targetKey,
    transaction,
    onVerified,
  } = options;
  const safe = options.redact ?? redact;
  return async function staffAdminBoundary(req, res, next) {
    const originalJson = res.json.bind(res),
      originalSend = res.send.bind(res);
    const restore = () => {
      res.json = originalJson;
      res.send = originalSend;
    };
    const answer = (status, body) => {
      restore();
      return res.status(status).json(body);
    };
    try {
      const authorization = req.get("Authorization");
      if (!authorization?.startsWith("Bearer "))
        throw fail("A corporate staff assertion is required", 401);
      let claims;
      if (options.verify) {
        claims = await options.verify(req);
      } else {
        const key = typeof secret === "function" ? secret() : secret;
        if (!key)
          throw fail("Corporate staff administration is not configured", 503);
        try {
          claims = jwt.verify(authorization.slice(7), key, {
            algorithms: ["HS256"],
            issuer: "ceo-dashboard",
          });
        } catch {
          throw fail("Invalid corporate staff assertion", 401);
        }
      }
      const requestHash = hashIntent({
        method: req.method,
        path: req.path,
        body: req.body ?? {},
        query: req.query,
      });
      const expectedProduct = typeof product === 'function' ? product() : product;
      if (typeof expectedProduct !== 'string' || !expectedProduct) throw fail('The product authority is not configured',503);
      if (
        typeof claims !== "object" ||
        claims.iss !== "ceo-dashboard" ||
        claims.product !== expectedProduct ||
        !/^staff:[A-Za-z0-9_-]{1,100}$/.test(claims.sub ?? "") ||
        claims.action !== `dashboard:${req.method}:${req.path}` ||
        claims.requestHash !== requestHash ||
        !Number.isInteger(claims.iat) ||
        !Number.isInteger(claims.exp) ||
        claims.exp <= Math.floor(Date.now() / 1000) ||
        claims.exp <= claims.iat ||
        claims.exp - claims.iat > 60 ||
        claims.iat > Math.floor(Date.now() / 1000) + 5
      )
        throw fail("Corporate assertion does not match this request", 403);
      const actorId = claims.sub.slice(6);
      res.setHeader("Cache-Control", "no-store");
      const actor = {
        id: actorId,
        role: claims.staffRole,
        name: claims.staffName,
        email: claims.staffEmail,
      };
      return await (options.context ?? ((_actor, run) => run()))(
        actor,
        async () => {
          await onVerified?.(req, actor);
          if (req.method === "GET") return next();
          const id = req.get("Idempotency-Key");
          if (
            !id ||
            !/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(
              id,
            ) ||
            claims.operationId !== id ||
            typeof claims.targetVersion !== "string" ||
            !claims.targetVersion
          )
            throw fail(
              "A saved operation and reviewed target version are required",
              400,
            );
          const fingerprint = hashIntent({
            requestHash,
            targetVersion: claims.targetVersion,
          });
          const claimed = await store.claim({
            id,
            actorId,
            method: req.method,
            path: req.path,
            requestHash: fingerprint,
            targetKey: targetKey(req),
          });
          if (!claimed) {
            const prior = await store.get(id);
            if (!prior)
              throw fail(
                "Another operation on this target is unresolved; inspect its original receipt",
                423,
              );
            if (prior.actorId !== actorId || prior.requestHash !== fingerprint)
              throw fail("Operation ID belongs to another reviewed intent");
            if (finalReceipt(prior))
              return answer(prior.responseStatus, prior.responseBody);
            throw fail(
              "Original operation is unresolved; investigate its receipt before another request",
            );
          }
          const external = options.external?.(req) === true;
          let result;
          let effectStarted = false;
          const run = async () => {
            const target = await reviewTarget(req, !external);
            if (target.version !== claims.targetVersion)
              throw fail(
                "Target changed since review; prepare a fresh request",
              );
            effectStarted = true;
            const captured = await capture(
              req,
              res,
              next,
              // A local handler may still be using its transaction after an HTTP
              // timeout. Keep the transaction/target held until it actually ends.
              external ? (options.timeoutMs ?? 60000) : null,
            );
            const body = safe(captured.body, req);
            if (captured.status >= 400 || body?.success !== true)
              throw Object.assign(
                fail(
                  typeof body?.error === "string"
                    ? body.error
                    : (body?.error?.message ??
                        body?.message ??
                        "Product operation failed"),
                  captured.status >= 400 ? captured.status : 502,
                ),
                { body },
              );
            await store.finish(id, "completed", captured.status, body);
            return {
              status: captured.status,
              body: options.oneTimeResult?.(req, captured.body, body) ?? body,
            };
          };
          try {
            result = external ? await run() : await transaction(run);
          } catch (error) {
            // An owning saga may have committed its business effects and
            // receipt together before a transport/response failure. That
            // durable result takes precedence over this handler's error.
            const terminal = await store.get(id);
            if (finalReceipt(terminal))
              return answer(terminal.responseStatus, terminal.responseBody);
            const status = error.status ?? error.statusCode ?? 500;
            const confirmedFailure =
              !effectStarted ||
              (!external && error.corporateRollbackConfirmed === true);
            const state = confirmedFailure ? "failed" : "unknown";
            const body = {
              ...safe(
                error.body ?? { success: false, error: error.message },
                req,
              ),
              operation: { id, state },
            };
            await store.finish(id, state, status, body);
            const saved = await store.get(id);
            if (finalReceipt(saved))
              return answer(saved.responseStatus, saved.responseBody);
            result = { status, body };
          }
          return answer(result.status, result.body);
        },
      );
    } catch (error) {
      return answer(error.status ?? error.statusCode ?? 503, {
        success: false,
        error: error.message,
      });
    }
  };
}
function operationRequest(operation, parameters) {
  const pathNames = [];
  const path = operation.path.replace(
    /:([A-Za-z][A-Za-z0-9_]*)/g,
    (_match, name) => {
      pathNames.push(name);
      const value = parameters[name];
      if (typeof value !== "string" || !/^[A-Za-z0-9_-]{1,100}$/.test(value))
        throw fail("Choose a valid record for " + name, 400);
      return encodeURIComponent(value);
    },
  );
  if (!path.startsWith("/") || /[?#]|\.\.|\\/.test(path))
    throw fail("Invalid native operation path", 502);
  return {
    path,
    body: {
      ...Object.fromEntries(
        Object.entries(parameters).filter(
          ([key, value]) => !pathNames.includes(key) && value !== undefined,
        ),
      ),
      ...(operation.fixedBody ?? {}),
    },
  };
}
function matchOperation(operations, method, path) {
  // Static routes (for example /tickets/stats) precede /tickets/:id.
  const ordered = Object.entries(operations).sort(
    ([, a], [, b]) =>
      (a.path.match(/:[A-Za-z]/g)?.length ?? 0) -
      (b.path.match(/:[A-Za-z]/g)?.length ?? 0),
  );
  for (const [name, operation] of ordered) {
    if (operation.method !== method) continue;
    const names = [];
    const pattern = operation.path
      .split("/")
      .map((part) =>
        part.startsWith(":")
          ? (names.push(part.slice(1)), "([A-Za-z0-9_-]{1,100})")
          : part.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"),
      )
      .join("/");
    const match = path.match(new RegExp("^" + pattern + "/?$"));
    if (match)
      return {
        name,
        operation,
        parameters: Object.fromEntries(
          names.map((key, i) => [key, match[i + 1]]),
        ),
      };
  }
  return null;
}
function workloadAudience(base, assertion) {
  const url = new URL(base);
  if (
    url.protocol !== "https:" ||
    url.username ||
    url.password ||
    url.search ||
    url.hash ||
    url.pathname !== "/"
  )
    throw fail("Invalid product workload identity URL", 503);
  return url.origin + "/staff-admin/assertions/" + hashIntent(assertion);
}
module.exports = {
  runtimeReviewVersion,
  productAuthority,
  runtimeProductEnvironment,
  runtimeProductAuthority,
  validateParams,
  hashIntent,
  redact,
  operationRequest,
  matchOperation,
  workloadAudience,
  createPostgresOperationStore,
  createStaffAdminBoundary,
};
