import { Request, Response, NextFunction, RequestHandler } from "express";
export function hashIntent(value: unknown): string;
export function productAuthority(product:string,environment:'prod'|'dev'):string;
export function runtimeProductEnvironment(product:string,serviceName?:string):'prod'|'dev';
export function runtimeProductAuthority(product:string,serviceName?:string):string;
export function runtimeReviewVersion(product:string,evidence:unknown,serviceName?:string,revisionName?:string):string;
export function redact(value: any): any;
export interface OperationRow {
  id: string;
  actorId: string;
  method: string;
  path: string;
  requestHash: string;
  targetKey: string;
  state?: string;
  responseStatus?: number;
  responseBody?: any;
}
export interface OperationStore {
  claim(row: OperationRow): Promise<boolean>;
  get(id: string): Promise<OperationRow | null>;
  finish(id: string, state: string, status: number, body: any): Promise<void>;
}
export function createPostgresOperationStore(
  query: (sql: string, values: unknown[]) => Promise<{ rows: any[] }>,
): OperationStore;
export interface BoundaryOptions {
  product: string | (()=>string);
  verify?: (req: Request) => Promise<any>;
  secret?: string | undefined | (() => string | undefined);
  store: OperationStore;
  reviewTarget: (
    req: Request,
    lock: boolean,
  ) => Promise<{ version: string; workspace?: any }>;
  targetKey: (req: Request) => string;
  transaction: <T>(run: () => Promise<T>) => Promise<T>;
  context?: <T>(
    actor: { id: string; role?: string; name?: string; email?: string },
    run: () => Promise<T>,
  ) => Promise<T>;
  onVerified?: (
    req: Request,
    actor: { id: string; role?: string; name?: string; email?: string },
  ) => void | Promise<void>;
  external?: (req: Request) => boolean;
  redact?: (value: any, req: Request) => any;
  oneTimeResult?: (req: Request, original: any, safe: any) => any;
  timeoutMs?: number;
}
export function createStaffAdminBoundary(
  options: BoundaryOptions,
): RequestHandler;

export function operationRequest(
  operation: { path: string; fixedBody?: Record<string, unknown> },
  parameters: Record<string, any>,
): { path: string; body: Record<string, any> };
export function matchOperation(
  operations: Record<string, any>,
  method: string,
  path: string,
): { name: string; operation: any; parameters: Record<string, string> } | null;

export function workloadAudience(base: string, assertion: unknown): string;

export type ParamsResult = { ok: true } | { ok: false; errors: string[] };
export function validateParams(
  schema: Record<string, unknown>,
  value: unknown,
): ParamsResult;
