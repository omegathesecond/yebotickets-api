# Corporate product administration boundary

Canonical source for `@omevision/product-admin-boundary`. Consumers use the same
packed archive, rather than fork authentication, validation or receipt handlers.
`./schema` is browser-safe; the root export is server-only.

The owning product supplies its operation catalogue, target/version checks,
transaction runner and existing business routers. The CEO API supplies a
currently active staff identity, resource grant, saved review, exact parameters,
operation ID and target version. No product-user account or session is created.

Use either a configured HS256 shared key or an explicitly configured workload
verifier. Workload callers use an audience containing the canonical hash of the
entire assertion; the product verifies the permitted Google service-account
email and that exact audience. There is no alternate authentication on failure.
The boundary checks issuer, product, staff subject, method/path, body/query hash,
60-second lifetime, saved operation ID and reviewed version.

Apply `migration.sql` in the product's normal migration route. The PostgreSQL
operation store must use the **same transaction client** as local business writes.
The first operation claims its ID and target durably before effects. Local writes,
critical audits and the successful receipt commit together. A local handler is
allowed to finish before releasing its client, even after the calling HTTP client
has timed out. Replays return the stored redacted receipt; a one-time credential
may be returned only by the explicit first-response hook.

Provider effects cannot be rolled back with SQL. Declare these operations as
external. Ambiguous provider, transport or commit outcomes remain `unknown`, hold
the target and require inspection of the original receipt. A provider HTTP 4xx is
not by itself proof that no effect occurred. Never retry under a new ID to clear
a hold. A local failure is conclusive only when the owning database confirms
rollback before commit was attempted.

`npm test --prefix packages/product-admin-boundary` exercises isolated HTTP and
in-memory receipt storage. The CEO API's guarded YeboLearn integration script
separately verifies real PostgreSQL effects, rollback, RLS and receipt replay.
These fixtures do not establish production Google identity or provider delivery.

Version 0.3 makes terminal receipts monotonic. An owning external-effect saga
can commit its entitlement changes and final receipt in one database transaction.
That durable receipt takes precedence over a later handler/transport error;
late `unknown` updates cannot replace a committed completion or failure. The Jobs
integration fixture verifies this against PostgreSQL as well as the HTTP boundary.

Version 0.4 shares `productAuthority(product, environment)` and trusted Cloud Run
runtime authority resolution. Source boundaries use
`product: () => runtimeProductAuthority('yebolearn')`, so environment validation
happens on the request and never derives from its claims or headers. A verified
`<product>-api-prod` or `<product>-api-dev` service selects one exact namespace;
missing, unknown, other-product or legacy service names fail with a configuration
error. Selected products do not accept their old unscoped assertion as an alias.
Verify the actual custom-domain mapping before adopting a service-name binding.
Local source fixtures set an explicit synthetic service name and use restricted
database roles; this does not establish production workload identity.

Before packing, run `npm run build --prefix packages/product-admin-boundary` to
regenerate `schema.cjs`. Commit identical archives and lockfile integrity in every
consumer. The source version is unreleased until the owning changes are reviewed
and deployed in product API → CEO API → dashboard order.


## Prisma on PostgreSQL

`createPrismaAdminScope` from `@omevision/product-admin-boundary/prisma` reuses
existing Prisma-based business handlers inside the operation transaction. Its
client proxy routes model queries and nested service transactions to the same
transaction client. Actor and transaction contexts use independent async-local
scopes and must be established only after corporate assertion verification.

The helper creates a PostgreSQL savepoint before running the handler. A handler
or critical audit failure is classified as confirmed rollback only after both
`ROLLBACK TO SAVEPOINT` and the outer commit are acknowledged. Lost rollback or
commit acknowledgement remains unknown. External provider effects must use the
boundary's external-operation mode instead; savepoints cannot undo those effects.
Disable automatic mutation retries in the owning client's reconnect middleware
while this corporate context is active. Run the package's real HTTP tests and
Prisma-scope failure tests with `npm test`.

Version 0.5 adds `runtimeReviewVersion(product, evidence)`. Custom owning
boundaries reuse it to bind their existing evidence to the exact immutable
Cloud Run source revision and trusted product/environment. `K_REVISION` must
belong to the verified `K_SERVICE`; missing, foreign and malformed values fail.
A source deployment invalidates old reviews even when its business rows have not
changed. This does not create a source revision or infer an environment.
