"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateParams = validateParams;
function isObj(v) {
    return typeof v === "object" && v !== null && !Array.isArray(v);
}
function typeMatches(expected, v) {
    switch (expected) {
        case "null":
            return v === null;
        case "object":
            return isObj(v);
        case "array":
            return Array.isArray(v);
        case "string":
            return typeof v === "string";
        case "boolean":
            return typeof v === "boolean";
        case "number":
            return typeof v === "number" && Number.isFinite(v);
        case "integer":
            return typeof v === "number" && Number.isInteger(v);
        default:
            return false;
    }
}
const KNOWN_TYPES = new Set([
    "object",
    "array",
    "string",
    "boolean",
    "number",
    "integer",
    "null",
]);
function checkField(path, spec, v, errors) {
    if (!isObj(spec))
        return;
    if (Array.isArray(spec.type)) {
        if (!spec.type.every((t) => typeof t === "string" && KNOWN_TYPES.has(t)) ||
            !spec.type.some((t) => typeMatches(t, v))) {
            errors.push(`${path}: unexpected type`);
            return;
        }
    }
    if (typeof spec.type === "string") {
        if (!KNOWN_TYPES.has(spec.type)) {
            errors.push(`${path}: unknown JSON Schema type keyword "${spec.type}"`);
            return;
        }
        if (!typeMatches(spec.type, v)) {
            errors.push(`${path}: expected type ${spec.type}`);
            return;
        }
    }
    if (typeof spec.minimum === "number" &&
        typeof v === "number" &&
        v < spec.minimum) {
        errors.push(`${path}: below minimum ${spec.minimum}`);
    }
    if (typeof spec.maximum === "number" &&
        typeof v === "number" &&
        v > spec.maximum) {
        errors.push(`${path}: above maximum ${spec.maximum}`);
    }
    if (typeof spec.minLength === "number" &&
        typeof v === "string" &&
        v.length < spec.minLength) {
        errors.push(`${path}: shorter than minLength ${spec.minLength}`);
    }
    if (typeof spec.maxLength === "number" &&
        typeof v === "string" &&
        v.length > spec.maxLength)
        errors.push(`${path}: exceeds maxLength`);
    if (typeof spec.pattern === "string" &&
        typeof v === "string" &&
        !new RegExp(spec.pattern).test(v))
        errors.push(`${path}: invalid format`);
    if (Array.isArray(v)) {
        if (typeof spec.minItems === "number" && v.length < spec.minItems)
            errors.push(`${path}: too few items`);
        if (typeof spec.maxItems === "number" && v.length > spec.maxItems)
            errors.push(`${path}: too many items`);
        if (spec.items)
            v.forEach((item, i) => checkField(`${path}[${i}]`, spec.items, item, errors));
    }
    if (isObj(v) && spec.properties) {
        const nested = validateParams(spec, v);
        if (nested.ok === false)
            errors.push(...nested.errors.map((error) => `${path}.${error}`));
    }
    if (Array.isArray(spec.enum) && !spec.enum.includes(v)) {
        errors.push(`${path}: not one of enum ${JSON.stringify(spec.enum)}`);
    }
}
function validateParams(schema, value) {
    const errors = [];
    if (schema.type === "object" || schema.properties !== undefined) {
        if (!isObj(value))
            return { ok: false, errors: ["payload must be an object"] };
        const required = Array.isArray(schema.required) ? schema.required : [];
        for (const key of required) {
            if (typeof key === "string" && value[key] === undefined) {
                errors.push(`${key}: required`);
            }
        }
        const props = isObj(schema.properties) ? schema.properties : {};
        if (schema.additionalProperties === false)
            for (const key of Object.keys(value))
                if (!Object.hasOwn(props, key))
                    errors.push(`${key}: unexpected field`);
        for (const [key, spec] of Object.entries(props)) {
            if (value[key] === undefined)
                continue;
            checkField(key, spec, value[key], errors);
        }
    }
    else {
        checkField("value", schema, value, errors);
    }
    return errors.length > 0 ? { ok: false, errors } : { ok: true };
}
