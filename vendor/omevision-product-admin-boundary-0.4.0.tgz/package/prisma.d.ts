export interface CorporateActor { id: string; role?: string; name?: string; email?: string }
export function createPrismaAdminScope<T extends object>(base: T, options?: { timeout?: number }): {
  client: T;
  actor(): CorporateActor | undefined;
  inTransaction(): boolean;
  context<R>(actor: CorporateActor, run: () => Promise<R>): Promise<R>;
  transaction<R>(run: () => Promise<R>): Promise<R>;
};
