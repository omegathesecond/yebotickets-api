const { AsyncLocalStorage } = require('node:async_hooks');
/** Scope existing business services to the operation's actual Prisma transaction. */
function createPrismaAdminScope(base, options = {}) {
  const transactions = new AsyncLocalStorage();
  const actors = new AsyncLocalStorage();
  const client = new Proxy(base, {
    get(target, key) {
      const tx = transactions.getStore();
      if (tx && key === '$transaction')
        return work => typeof work === 'function' ? work(tx) : Promise.all(work);
      const owner = tx && key in tx ? tx : target;
      const value = Reflect.get(owner, key);
      return typeof value === 'function' ? value.bind(owner) : value;
    },
  });
  return {
    client,
    actor: () => actors.getStore(),
    inTransaction: () => Boolean(transactions.getStore()),
    context: (actor, run) => actors.run(actor, run),
    async transaction(run) {
      if (transactions.getStore()) return run();
      // Acknowledged rollback to our savepoint, followed by an acknowledged
      // outer commit, proves no handler/audit/receipt effects survived.
      // Transport, rollback or commit failures remain unclassified/unknown.
      const outcome = await base.$transaction(async tx => {
        await tx.$executeRawUnsafe('SAVEPOINT corporate_staff_operation');
        try {
          return { ok: true, value: await transactions.run(tx, run) };
        } catch (error) {
          await tx.$executeRawUnsafe('ROLLBACK TO SAVEPOINT corporate_staff_operation');
          return { ok: false, error };
        }
      }, { timeout: options.timeout ?? 65000 });
      if (!outcome.ok) throw Object.assign(outcome.error, { corporateRollbackConfirmed: true });
      return outcome.value;
    },
  };
}
module.exports = { createPrismaAdminScope };
