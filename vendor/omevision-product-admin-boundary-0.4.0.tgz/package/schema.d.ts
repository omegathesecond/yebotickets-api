export type ParamsResult={ok:true}|{ok:false;errors:string[]};
export function validateParams(schema:Record<string,unknown>,value:unknown):ParamsResult;
